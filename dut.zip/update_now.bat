@echo off
chcp 65001 >nul
echo 🚀 Обновление файлов на GitHub...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $token='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'; $repoOwner='volkonskiy93-cyber'; $repoName='-2'; $baseUrl='https://api.github.com/repos/'+$repoOwner+'/'+$repoName+'/contents'; $files=@('index.html','deepseek_htmlобщая.html','admin.html'); $success=0; $error=0; foreach($f in $files){ Write-Host \"📄 Обновление: $f\" -ForegroundColor Cyan; try{ $c=Get-Content $f -Raw -Encoding UTF8; $b=[System.Text.Encoding]::UTF8.GetBytes($c); $b64=[Convert]::ToBase64String($b); try{ $ex=Invoke-RestMethod -Uri ($baseUrl+'/'+$f) -Headers @{Authorization='token '+$token; Accept='application/vnd.github.v3+json'} -Method Get; $sha=$ex.sha }catch{$sha=$null}; $body=@{message='Update iOS 26 styles'; content=$b64}; if($sha){$body.sha=$sha}; $json=$body|ConvertTo-Json -Compress; Invoke-RestMethod -Uri ($baseUrl+'/'+$f) -Method Put -Headers @{Authorization='token '+$token; Accept='application/vnd.github.v3+json'; 'Content-Type'='application/json'} -Body $json -ContentType 'application/json' | Out-Null; Write-Host \"  ✅ $f успешно обновлен!\" -ForegroundColor Green; $success++ }catch{ Write-Host \"  ❌ Ошибка: $($_.Exception.Message)\" -ForegroundColor Red; $error++ }; Start-Sleep -Seconds 1 }; Write-Host \"\n═══════════════════════════════════════════════════\" -ForegroundColor Magenta; Write-Host \"📊 Результаты: ✅ $success  ❌ $error\" -ForegroundColor Magenta; Write-Host \"═══════════════════════════════════════════════════\" -ForegroundColor Magenta }"

pause
