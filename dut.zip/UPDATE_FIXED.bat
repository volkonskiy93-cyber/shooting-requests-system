@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
set GH_TOKEN=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

echo ========================================
echo   ОБНОВЛЕНИЕ ФАЙЛОВ НА GITHUB
echo ========================================
echo.

cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File update_simple.ps1

echo.
echo ========================================
echo   ГОТОВО!
echo ========================================
echo.
pause
