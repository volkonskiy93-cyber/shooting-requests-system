@echo off
setlocal enabledelayedexpansion
set GH_TOKEN=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

echo ========================================
echo   ОБНОВЛЕНИЕ ФАЙЛОВ НА GITHUB
echo ========================================
echo.

cd /d "%~dp0"

echo Обновление файлов через GitHub CLI...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:GH_TOKEN='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'; $files=@('index.html','deepseek_htmlобщая.html','admin.html'); $successCount=0; $errorCount=0; foreach($f in $files){ if(Test-Path $f){ Write-Host \"Обновление $f...\" -NoNewline; try{ $c=Get-Content $f -Raw -Encoding UTF8; $b=[System.Text.Encoding]::UTF8.GetBytes($c); $b64=[Convert]::ToBase64String($b); $shaOutput=gh api repos/volkonskiy93-cyber/-2/contents/$f --method GET --jq .sha 2>&1; $sha=$shaOutput | Select-String -Pattern '^[a-f0-9]{40}$' | ForEach-Object { $_.Matches.Value }; $bodyFile=[System.IO.Path]::GetTempFileName(); if($sha){ $body=@\"{\"message\":\"Update iOS 26 styles\",\"content\":\"$b64\",\"sha\":\"$sha\"}\"@ }else{ $body=@\"{\"message\":\"Update iOS 26 styles\",\"content\":\"$b64\"}\"@ }; $body | Out-File -FilePath $bodyFile -Encoding UTF8 -NoNewline; gh api repos/volkonskiy93-cyber/-2/contents/$f --method PUT --input $bodyFile 2>&1 | Out-Null; Remove-Item $bodyFile -Force; if($LASTEXITCODE -eq 0){ Write-Host \" OK\" -ForegroundColor Green; $successCount++ }else{ Write-Host \" ERROR\" -ForegroundColor Red; $errorCount++ } }catch{ Write-Host \" ERROR: $($_.Exception.Message)\" -ForegroundColor Red; $errorCount++ }; Start-Sleep -Milliseconds 500 }else{ Write-Host \"$f не найден\" -ForegroundColor Red; $errorCount++ } }; Write-Host \"\nРезультат: Success=$successCount Errors=$errorCount\" -ForegroundColor $(if($errorCount -eq 0){'Green'}else{'Yellow'})"

echo.
echo ========================================
echo   ГОТОВО!
echo ========================================
echo.
pause
